from flask import Flask, render_template, request
import pandas as pd
import joblib

app = Flask(__name__)

# Load the dataset
data = pd.read_csv("updated_skincare_data_with_skin_types.csv")

# List of skin types
skin_types = ['oily', 'dry', 'combination', 'sensitive', 'normal']

# Create binary columns for each skin type based on the 'skin_type' column
for skin in skin_types:
    data[f"is_{skin}"] = data['skin_type'].str.lower() == skin

# Load the models
models = {skin: joblib.load(f"model_{skin}.pkl") for skin in skin_types}

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/recommend', methods=['GET', 'POST'])
def recommend():
    if request.method == 'POST':
        skin_type = request.form.get('skin_type', '').strip().lower()

        # Validate skin type
        if skin_type not in skin_types:
            error_message = f"Invalid skin type '{skin_type}'. Please enter one of: {', '.join(skin_types)}."
            return render_template('recommend.html', error=error_message, recommendations=[])

        # Filter compatible products
        compatible_products = data[data[f"is_{skin_type}"]]

        if compatible_products.empty:
            return render_template('recommend.html', recommendations=None, skin_type=skin_type)

        product_list = compatible_products[['product_name', 'benefits']].to_dict(orient='records')
        return render_template('recommend.html', recommendations=product_list, skin_type=skin_type)

    return render_template('recommend.html', recommendations=None)

@app.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        ingredients = request.form.get('ingredients', '').strip().lower()
        ingredient_list = [i.strip() for i in ingredients.split(',') if i.strip()]

        # Create feature vector
        all_ingredients = set(data['ingredients_list'].str.split(',').sum())
        feature_vector = [1 if ingredient in ingredient_list else 0 for ingredient in all_ingredients]

        # Predict compatibility for each skin type
        predictions = {}
        for skin, model in models.items():
            predictions[skin] = "Compatible" if model.predict([feature_vector])[0] == 1 else "Not Compatible"

        return render_template('predict.html', predictions=predictions)

    return render_template('predict.html', predictions=None)

if __name__ == '__main__':
    app.run(debug=True)













